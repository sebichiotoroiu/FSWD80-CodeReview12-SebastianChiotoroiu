<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package cr12_sebastian_chiotoroiu_traveler
 */

get_header();
?>




<div class="container">
	<div class="alert alert-primary" role="alert ">
		<div class="destination">
			<h2 class="dest-title">Destinations </h2>
			<p class="dest-text">We are the Mirko Traveler, your favorite travel assistants! </p>
		</div>
	</div>

<div class="container">
<div class="card-deck">
  <div class="card">
    <img src="https://cdn.pixabay.com/photo/2017/01/14/13/59/castelmezzano-1979546__340.jpg" class="card-img-top" alt="...">
    <div class="card-body">
      <h5 class="card-title">Castelmezzano Italy</h5>
      <p class="card-text">THINGS TO SEE AND DO IN ITALY: Suggested daily budget – 50-60 EUR / 52-62 USD </p>
      <a href="http://localhost:8080/FSWD80-CodeReview12-SebastianChiotoroiu/1-2/" class="btn btn-primary">Explore</a>
    </div>
    <div class="card-footer">
      <small class="text-muted">Last updated 4 days ago</small>
    </div>
  </div>
  <div class="card">
    <img src="https://cdn.pixabay.com/photo/2019/10/25/20/55/mountains-4578133_1280.jpg" class="card-img-top" alt="...">
    <div class="card-body">
      <h5 class="card-title">Grosser Aletsch Glacier</h5>
      <p class="card-text">THINGS TO SEE AND DO IN CANADA: Suggested daily budget – 80-90 EUR / 84-95 USD</p>
      <a href="http://localhost:8080/FSWD80-CodeReview12-SebastianChiotoroiu/2-2/" class="btn btn-primary">Explore</a>
    </div>
    <div class="card-footer">
      <small class="text-muted">Last updated 10 mins ago</small>
    </div>
  </div>
  <div class="card">
    <img src="https://cdn.pixabay.com/photo/2018/06/25/15/43/the-alps-3497198__340.jpg" class="card-img-top" alt="...">
    <div class="card-body">
      <h5 class="card-title">Alps</h5>
      <p class="card-text">THINGS TO SEE AND DO IN FRANCE: Suggested daily budget – 55-60 EUR / 56-62 USD</p>
      <a href="http://localhost:8080/FSWD80-CodeReview12-SebastianChiotoroiu/3-2/" class="btn btn-primary">Explore</a>
    </div>
    <div class="card-footer">
      <small class="text-muted">Last updated 7 days ago</small>
    </div>
  </div>
</div>
</div>
<br>

<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
  <ol class="carousel-indicators">
    <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
  </ol>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="https://cdn.pixabay.com/photo/2017/07/23/21/07/mountains-2532825_1280.jpg" alt="...">
    </div>
    <div class="carousel-item">
      <img src="https://cdn.pixabay.com/photo/2016/08/26/17/24/landscape-1622718_1280.jpg" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="https://cdn.pixabay.com/photo/2018/05/14/16/54/alpine-3400788_1280.jpg" class="d-block w-100" alt="...">
    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
<br>

<div class="row">
<div class="col-lg-8 col-md-12 col-sm-11">
<div class="card-group">

<?php if ( have_posts() ) :?>

<?php 
while(have_posts()) : the_post();
?>
  <div class="col-lg-5 col-md-6 col-sm-11">
    <div class="card">
    	<div class="card-body">
      <h2 class="blog-post-title">
            <a href="<?php the_permalink(); ?>">
             <?php the_title(); ?> </h2></a>
      <p class="card-text"><?php the_content(); ?></p>
      <p class="card-text blog-post-meta"><small class="text-muted"><?php the_time('F j, Y g:i a'); ?></small></p>
    </div>
  </div>
</div>
  
<?php
			endwhile;

			the_posts_navigation();

		else :

			get_template_part( 'template-parts/content', 'none' );

		endif;
		?>

		</main><!-- #main -->
	</div><!-- #primary -->

</div>

	<div class="col-3">	
	<?php
get_sidebar();
?>
	</div>
</div>
<?php
get_footer();
?>

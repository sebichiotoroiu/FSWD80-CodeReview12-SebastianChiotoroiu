<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package cr12_sebastian_chiotoroiu_traveler
 */

get_header();
?>
<div class="row m-4">
		<div class="site-main col-lg-8 col-md-11 col-sm-11">

		<div class="card-group">

		<?php if ( have_posts() ) :?>

		<?php
		while ( have_posts() ) : the_post(); ?>
		<div class="card col-lg-8 col-md-11 col-sm-11 border-0">
 			<h2 class="blog-post-title pb-2"><?php the_title(); ?></h2>
    	<div class="card-body">
	      	<p class="card-text"><?php the_content(); ?></p>
    	  	<p class="card-text blog-post-meta"><small class="text-muted"><?php the_time('F j, Y g:i a'); ?></small></p>
    	</div>
			<?php if ( comments_open() || get_comments_number() ) : comments_template();
			endif; ?>
  		</div>
			
			<?php 
		endwhile; 
		else :

		get_template_part( 'template-parts/content', 'none' );

		endif;
		?>

		</div>
	</div>

<?php
get_sidebar();
get_footer();
